import{q as a}from"./BZYip4vB.js";a();
